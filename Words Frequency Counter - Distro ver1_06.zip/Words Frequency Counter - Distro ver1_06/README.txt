---\ READ ME BEFORE USE /---

1) TO START APP USE MAIN.EXE AND FOLLOW INSTRUCTIONS IN TOP OF THE WINDOW
2) EVERY FILE IS ESSENTIAL FOR APP TO WORK
3) THERE IS EXAMPLE FILE INCLUDED - HAMLET
4) YOU CAN SWAP THE wordsToAvoid.txt FILE FOR one with different words set IF YOU TRY TO SCAN TEXT IN DIFFERENT LANGUAGE
5) The app should not need any Python libraries to run - made for Windows (tested only on Win10)

Made by
Krzysztof Szumko (09 - April - 2019)